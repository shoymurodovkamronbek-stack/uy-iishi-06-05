import os
os.system("cls")
f = open("ascii.txt", "r")
sonlar = f.read().split()
f.close()
matn = ""
for i in sonlar:
    matn += chr(int(i))
f = open("natija.txt", "w")
f.write(matn)
f.close()
print(matn)