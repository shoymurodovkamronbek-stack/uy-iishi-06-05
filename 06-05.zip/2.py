import os
os.system("cls")
soz = input("So'z kiriting: ").lower()
f = open("matn.txt", "r")
matn = f.read().lower()
f.close()
if matn.find(soz) != -1:
    print("Siz kiritgan so'z faylda bor.")
else:
    print("Siz kiritgan so'z faylda yo'q.")