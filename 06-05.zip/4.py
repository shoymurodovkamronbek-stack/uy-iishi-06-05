import os
os.system("cls")
f = open("sonlar.txt", "r")
sonlar = f.read().split()
f.close()
summa = 0
for i in sonlar:
    summa += int(i)

orta = round(summa / len(sonlar))
print(orta)